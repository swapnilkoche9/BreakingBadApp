module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
}