import Vue from "vue";
import Router from "vue-router";
import CharacterCatalogue from "../components/CharacterCatalogue";
import CharacterDetails from "../components/CharacterDetails";
import PageNotFound from "../components/PageNotFound";
import PopularCasts from "../components/PopularCasts";

Vue.use(Router);

const router = new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "catelogue",
      component: CharacterCatalogue
    },
    {
      path: "/details/:id",
      name: "details",
      component: CharacterDetails
    },
    {
      path: "/popularcasts",
      name: "popularcasts",
      component: PopularCasts
    },
    {
      path: "*",
      name: "pageNotFound",
      component: PageNotFound
    }
  ]
});

export default router;
