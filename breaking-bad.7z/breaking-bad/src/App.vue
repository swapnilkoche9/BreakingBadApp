<template>
  <v-app id="inspire">
    <v-app-bar app color="indigo" dark>
      <v-btn
        v-if="famousCharacterButtonVisibility"
        small
        v-on:click="famousCharacter()"
        color="gray"
        absolute
        bottom
        right
      >
        {{ popularCastLabel }}
      </v-btn>
      <v-icon class="back-arrow" v-if="backButtonVisibility" @click="goBack">{{
        icons.mdiArrowLeft
      }}</v-icon>
      <v-toolbar-title>{{ applicationTitle }}</v-toolbar-title>
    </v-app-bar>
    <v-content>
      <v-container class="fill-height" fluid>
        <router-view></router-view>
      </v-container>
    </v-content>
    <v-footer color="indigo" app>
      <span class="white--text">&copy; {{ footerLabel }}</span>
    </v-footer>
  </v-app>
</template>

<script>
import { mapState } from "vuex";
import { mdiArrowLeft } from "@mdi/js";
import constants from "./constants/constants.json";
export default {
  name: "App",
  data: () => ({
    icons: {
      mdiArrowLeft
    },
    popularCastLabel: constants.popularCastLabel,
    applicationTitle: constants.applicationTitle,
    footerLabel: constants.footerLabel
  }),
  computed: {
    ...mapState(["backButtonVisibility", "famousCharacterButtonVisibility"])
  },
  methods: {
    famousCharacter: function() {
      this.$router.push("/popularcasts");
    },

    goBack: function() {
      this.$router.push("/");
    }
  }
};
</script>
<style scoped>
.container.fill-height {
  display: flex;
  align-items: flex-start;
}
.back-arrow {
  margin-right: 20px;
}
</style>
