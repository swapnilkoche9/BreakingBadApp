<template>
  <v-card class="mx-auto" max-width="434" tile>
    <v-img height="100%" src="../assets/logo.jpg" v-if="selectedCharacter">
      <v-row align="end" class="fill-height">
        <v-col align-self="start" class="pa-0" cols="12">
          <v-avatar class="profile" color="grey" size="164" tile>
            <v-img v-bind:src="selectedCharacter.img"></v-img>
          </v-avatar>
        </v-col>
        <v-col class="py-0">
          <v-list-item color="rgba(0, 0, 0, .4)" dark>
            <v-list-item-content>
              <v-list-item-title class="title">{{
                selectedCharacter.name
              }}</v-list-item-title>
              <div class="character-info">
                <div class="label">
                  <v-label>{{ dob }}</v-label>
                </div>
                <div class="value">
                  <v-label>{{ selectedCharacter.birthday }}</v-label>
                </div>
              </div>
              <div class="character-info">
                <div class="label">
                  <v-label>{{ status }}</v-label>
                </div>
                <div class="value">
                  <v-label>{{ selectedCharacter.status }}</v-label>
                </div>
              </div>
              <div class="character-info">
                <div class="label">
                  <v-label>{{ nickName }}</v-label>
                </div>
                <div class="value">
                  <v-label>{{ selectedCharacter.nickname }}</v-label>
                </div>
              </div>
              <div class="character-info">
                <div class="label">
                  <v-label>{{ occupations }}</v-label>
                </div>
                <div class="value">
                  <div
                    v-bind:key="occ"
                    v-for="occ in selectedCharacter.occupation"
                  >
                    <v-label>{{ occ }}</v-label>
                  </div>
                </div>
              </div>
            </v-list-item-content>
          </v-list-item>
        </v-col>
      </v-row>
    </v-img>
    <v-img
      height="100%"
      src="../assets/logo.jpg"
      v-if="!selectedCharacter && !isLoading"
      ><h2 class="no-record-lable">{{ noRecordFoundLabel }}</h2></v-img
    >
  </v-card>
</template>

<script>
import { mapState } from "vuex";
import constants from "../constants/constants.json";
export default {
  name: "CharacterDetails",
  computed: {
    ...mapState(["characters", "selectedCharacter"])
  },
  data: () => ({
    isLoading: false,
    noRecordFoundLabel: constants.noRecordFoundLabel,
    dob: constants.dob,
    status: constants.status,
    nickName: constants.nickName,
    occupations: constants.occupations
  }),
  beforeMount() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", true);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", false);
    this.isLoading = true;
    if (this.$store.state.characters.length === 0) {
      this.$store
        .dispatch("getCharacters")
        .then(() => {
          this.$store.commit(
            "SET_SELECTED_CHARACTER",
            this.characters.filter(
              character =>
                character.char_id.toString() ===
                this.$route.params.id.toString()
            )[0]
          );
          this.isLoading = false;
        })
        .catch(error => {
          console.log(error);
        });
    }
  },

  beforeDestroy() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", false);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", true);
  }
};
</script>
<style scoped>
.character-info {
  display: flex;
  flex-direction: row;
  margin-top: 10px;
}
.container.fill-height {
  align-items: flex-start;
}
.theme--light.v-label {
  color: silver;
}
.value {
  margin-left: 10px;
}
.no-record-lable {
  display: flex;
  margin: 20px;
  color: white;
}
.profile {
  height: 200px !important;
}
</style>
