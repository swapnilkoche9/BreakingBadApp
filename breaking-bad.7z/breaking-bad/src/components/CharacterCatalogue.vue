<template>
  <div>
    <v-text-field
      class="search-box"
      v-model="searchValue"
      append-icon="mdi-magnify"
      label="Search"
      single-line
      hide-details
      @input="filterResults"
    ></v-text-field>
    <v-select
      class="select-box"
      v-model="selectedValues"
      :items="items"
      attach
      chips
      label="Filter By Status"
      multiple
      @change="filterResults"
    ></v-select>
    <CharacterList
      v-if="characters"
      class="character-list"
      v-bind:characters="characters"
    />
    <v-label v-if="characters.length === 0 && !isLoading">{{
      noRecordFoundLabel
    }}</v-label>
  </div>
</template>

<script>
import constants from "../constants/constants.json";
import CharacterList from "./CharacterList";
export default {
  name: "CharacterCatalogue",
  components: {
    CharacterList
  },
  data: function() {
    return {
      isLoading: false,
      characters: this.$store.getters.characters,
      searchValue: "",
      items: ["Alive", "Deceased", "Presumed dead", "unknown"],
      selectedValues: [],
      noRecordFoundLabel: constants.noRecordFoundLabel
    };
  },
  beforeMount() {
    if (this.$store.state.characters.length === 0) {
      this.isLoading = true;
      this.$store.dispatch("getCharacters").then(() => {
        this.characters = this.$store.getters.characters;
        this.isLoading = false;
      });
    }
  },

  methods: {
    filterResults: function() {
      if (this.searchValue === "" && this.selectedValues.length === 0) {
        this.characters = this.$store.getters.characters;
      } else {
        this.characters = this.$store.getters.characters
          .filter(
            character =>
              character.name
                .toLowerCase()
                .includes(this.searchValue.toLowerCase()) ||
              character.status
                .toLowerCase()
                .includes(this.searchValue.toLowerCase())
          )
          .filter(character =>
            this.selectedValues.length > 0
              ? this.selectedValues.includes(
                  character.status === "?" ? "unknown" : character.status
                )
              : true
          );
      }
    }
  }
};
</script>
<style scoped>
.search-box {
  display: flex;
  width: 250px;
  justify-content: flex-end;
  position: absolute;
  right: 10px;
  margin-top: 15px;
}

.select-box {
  display: flex;
  width: 250px;
  justify-content: flex-end;
}
</style>
