<template>
  <div class="character-list">
    <div v-bind:key="character.id" v-for="character in characters">
      <CharacterItem v-bind:character="character" />
    </div>
  </div>
</template>

<script>
import CharacterItem from "./CharacterItem";
export default {
  name: "CharacterList",
  props: ["characters"],

  components: {
    CharacterItem
  }
};
</script>

<style scoped>
.character-list {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -2.5px;
  padding: 10px 2.5px 0;
  @media (min-width: 768px) {
    width: 50%;
  }
  @media (min-width: 1024px) {
    width: 25%;
  }
}
</style>
