<template>
  <div class="character-item" @click="goToDetailsPage">
    <div class="character-image">
      <v-img
        v-bind:src="character.img"
        aspect-ratio="1"
        class="grey lighten-2 image"
        max-width="150"
      >
      </v-img>
    </div>
    <div class="content">
      <div class="name">{{ character.name }}</div>
      <div class="status">
        {{ character.status === "?" ? "unknown" : character.status }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "CharacterItem",
  props: ["character"],

  methods: {
    goToDetailsPage: function() {
      this.$store.commit("SET_SELECTED_CHARACTER", this.character);
      this.$router.push("/details/" + this.character.char_id);
    }
  }
};
</script>

<style scoped>
.character-item {
  width: 150px;
  display: flex;
  flex-direction: column;
  margin: 20px;
}
.character-item:hover {
  border: 2px solid #2781ff;
  border-radius: 6px;
}
.character-image {
  position: relative;
  width: 100%;
  background-color: rgb(242, 242, 242);
  height: 0px;
  padding-top: 133%;
  border-radius: 2px;
  overflow: hidden;
}

.image {
  position: absolute;
  height: auto;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  object-position: center center;
  height: 100%;
  width: 100%;
  object-fit: contain;
}
.content {
  line-height: 1.4em;
  display: flex;
  padding-top: 10px;
  flex-direction: column;
  justify-content: center;
}
.name {
  font-size: 12px;
  font-weight: bold;
  display: flex;
  justify-content: center;
}
.status {
  font-size: 12px;
  display: flex;
  justify-content: center;
}
</style>
