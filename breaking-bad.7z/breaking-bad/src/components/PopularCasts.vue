<template>
  <v-content v-if="characters">
    <v-card>
      <v-card-title>
        {{ dataTableTitle }}
        <v-spacer></v-spacer>
        <v-text-field
          v-model="search"
          label="Search"
          single-line
          hide-details
        ></v-text-field>
      </v-card-title>
      <v-data-table
        :headers="headers"
        :items="characters"
        :search="search"
        :items-per-page="5"
      >
        <template v-slot:item.img="{ item }">
          <div class="image">
            <v-img height="100%" width="30px" v-bind:src="item.img" />
          </div>
        </template>
      </v-data-table>
    </v-card>
  </v-content>
</template>

<script>
//import constants from "../constants.json";
export default {
  name: "PopularCasts",
  data: function() {
    return {
      characters: this.$store.getters.famousCharacter,
      search: "",
      dataTableTitle: "Casts Appeared in all the 5 Seasons ",
      headers: [
        {
          text: "",
          align: "right",
          value: "img"
        },
        { text: "NAME", value: "name" },
        { text: "NICKNAME", value: "nickname" },
        { text: "STATUS", value: "status" },
        { text: "DOB", value: "birthday" }
      ]
    };
  },
  beforeMount() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", true);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", false);
    if (this.$store.state.characters.length === 0)
      this.$store.dispatch("getCharacters").then(() => {
        this.characters = this.$store.getters.famousCharacter;
      });
  },

  beforeDestroy() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", false);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", true);
  }
};
</script>
<style>
.image {
  padding: 3px;
}
</style>
