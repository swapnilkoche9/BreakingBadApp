<template>
  <div class="page-not-found">
    <v-img height="50%" src="../assets/logo.jpg"
      ><h2 class="not-found-lable">{{ pageNotFoundText }}</h2></v-img
    >
  </div>
</template>

<script>
import constants from "../constants/constants.json";
export default {
  name: "PageNotFound",
  data: function() {
    return {
      pageNotFoundText: constants.pageNotFoundText
    };
  },
  methods: {
    goBack: function() {
      this.$router.push("/");
    }
  },
  beforeMount() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", true);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", false);
  },

  beforeDestroy() {
    this.$store.commit("SET_BACK_BUTTON_VISIBILITY", false);
    this.$store.commit("SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY", true);
  }
};
</script>
<style scoped>
.page-not-found {
  width: 500px;
  position: absolute;
  left: 30%;
}
.not-found-lable {
  display: flex;
  margin: 20px;
  color: white;
}
</style>
