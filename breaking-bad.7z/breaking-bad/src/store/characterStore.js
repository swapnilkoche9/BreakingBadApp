import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";

Vue.use(Vuex, axios);

export default new Vuex.Store({
  state: {
    characters: [],
    selectedCharacter: null,
    backButtonVisibility: false,
    famousCharacterButtonVisibility: true
  },

  actions: {
    async getCharacters({ commit }) {
      await axios
        .get("https://www.breakingbadapi.com/api/characters")
        .then(response => {
          commit("SET_CHARACTERS", response.data);
        })
        .catch(error => {
          console.log(error);
        });
    }
  },
  mutations: {
    SET_CHARACTERS: (state, characters) => {
      state.characters = characters;
    },
    SET_SELECTED_CHARACTER: (state, selectedCharacter) => {
      state.selectedCharacter = selectedCharacter;
    },
    SET_BACK_BUTTON_VISIBILITY: (state, visibility) => {
      state.backButtonVisibility = visibility;
    },
    SET_FAMOUS_CHARACTERS_BUTTON_VISIBILITY: (state, visibility) => {
      state.famousCharacterButtonVisibility = visibility;
    }
  },

  getters: {
    characters: state => {
      return state.characters;
    },
    selectedCharacter: state => {
      return state.selectedCharacter;
    },
    famousCharacter: state => {
      return state.characters.filter(
        character => character.appearance.length === 5
      );
    }
  }
});
